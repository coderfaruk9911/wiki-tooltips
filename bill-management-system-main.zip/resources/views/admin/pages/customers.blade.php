@extends('admin.layouts.master')

@section('admin-content')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Customer List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a></li>
              <li class="breadcrumb-item active">Customer</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Error Massage -->
    <div class="container">
      <div class="row d-flex justify-content-center">
          <div class="col-6">
              @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
              @endif
          </div>
      </div>
  </div>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <a href="#" data-toggle="modal" data-target="#modal-lg" class="btn btn-primary float-right">Add New customer</a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>SL</th>
                    <th>UserId</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>mobile</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>

                    @foreach ($allCustomer as $key => $row)
                    <tr>
                        <td>{{++$key}}</td>
                        <td>{{$row->user_id}}</td>
                        <td>{{$row->name}}</td>
                        <td>{{$row->price - $row->discount_price}}</td>
                        <td>{{$row->mobile}}</td>
                        <td>
                          <a href="{{route('customer.delete',$row->user_id)}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                          <a href="{{route('customer.edit',$row->user_id)}}" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                          <a href="{{route('customer.details',$row->user_id)}}" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a>
                        </td>
                    </tr>
                    @endforeach
                  
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>



  <!-- modal-dialog -->
  <div class="modal fade" id="modal-lg" >
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
          <h4 class="modal-title">Add New Customer</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <form action="{{route('customer.store')}}" method="post">
            @csrf
        <div class="modal-body">
          
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="name">Customer Name</label>
                            <input type="text" id="name" name="name" class="form-control">
                          </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                        <label for="inputStatus">Package</label>
                        <select id="inputStatus" name="package_id" class="form-control custom-select">
                            <option selected disabled>Select Package</option>
                            @foreach ($allPackage as $package)
                                <option value="{{$package->id}}">{{$package->package_name}}</option>
                            @endforeach
                        </select>
                        </div>
                    </div>
                </div>

                <div class="row">

                  <div class="col-8">
                    <div class="form-group">
                      <label for="inputowner">Home Owner Name</label>
                      <input type="text" id="inputowner" name="home_owner_name" class="form-control">
                    </div>
                  </div>

                  <div class="col-4">
                    <div class="form-group">
                        <label for="discount_price">Discount Price</label>
                        <input type="number" name="discount_price" id="discount_price" class="form-control">
                      </div>
                </div>

                </div>
                 

                  <div class="form-group">
                    <label for="inputDescription">Address</label>
                    <textarea id="inputDescription" name="address" class="form-control" rows="4"></textarea>
                  </div>


                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="inputmobile">Mobile</label>
                            <input type="text" name="mobile" id="inputmobile" class="form-control">
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="inputmobile">Connection Date</label>
                            <input type="date" name="connection_date" id="inputmobile" class="form-control">
                        </div>
                    </div>
                </div>
                  
              </div>
            
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
        </form>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

@endsection