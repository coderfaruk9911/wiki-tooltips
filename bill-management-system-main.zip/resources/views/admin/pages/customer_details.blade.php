@extends('admin.layouts.master')


@section('admin-content')
<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="float-right"></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a></li>
              <li class="breadcrumb-item"><a href="{{route('customer.view')}}">All Customer</a></li>
              <li class="breadcrumb-item active">{{$customer->name}} Details</li>
            </ol>
          </div>
        </div>
      </div>
    </section>


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-8">


            <div class="card card-widget widget-user">
              <div class="widget-user-header bg-info">
                <h3 class="widget-user-username">{{$customer->name}} Details</h3>
                <h5 class="widget-user-desc">{{$customer->user_id}}</h5>
              </div>
              <div class="card-footer">
                <div class="row">
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header">Package Name</h5>
                      <span class="description-text">{{$customer->package_name}}</span>
                    </div>
                  </div>
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header">Speed(MBPS)</h5>
                      <span class="description-text">{{$customer->speed}}</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="description-block">
                      <h5 class="description-header">Mobile</h5>
                      <span class="description-text">{{$customer->mobile}}</span>
                    </div>
                  </div>
                  <hr class="w-100">

                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header">General Price</h5>
                      <span class="description-text">{{$customer->price}}</span>
                    </div>
                  </div>
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header">Discount Price</h5>
                      <span class="description-text">{{$customer->discount_price}}</span>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="description-block">
                      <h5 class="description-header">Granted Price</h5>
                      <span class="description-text">{{$customer->price - $customer->discount_price}}</span>
                    </div>
                  </div>

                  <hr class="w-100">

                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header">Home Owner Name</h5>
                      <span class="description-text">{{$customer->home_owner_name}}</span>
                    </div>
                  </div>
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header">Joining Date</h5>
                      <span class="description-text">{{$customer->connection_date}}</span>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="description-block">
                      <h5 class="description-header">Address</h5>
                      <span class="description-text">{{$customer->address}}</span>
                    </div>
                  </div>


                </div>

            
                
                </div>


              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
@endsection