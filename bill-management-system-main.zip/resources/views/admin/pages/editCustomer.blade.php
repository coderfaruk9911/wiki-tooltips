@extends('admin.layouts.master')


@section('admin-content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="float-right">Update Customer Info</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a></li>
              <li class="breadcrumb-item"><a href="{{route('customer.view')}}">All Customer</a></li>
              <li class="breadcrumb-item active">Edit Customer</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Error  Massage Coderfaruk -->
    <div class="container">
      <div class="row d-flex justify-content-center">
          <div class="col-6">
              @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
              @endif
          </div>
      </div>
  </div>
  <!-- End Error  Massage Coderfaruk -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-8">

            <div class="card">
                <form action="{{route('customer.update',$editData->id)}}" method="post">
                    @csrf
                    <div class="card-body">

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="name">Customer Name</label>
                                    <input type="text" id="name" name="name" value="{{$editData->name}}" class="form-control">
                                  </div>
                            </div>
        
                            <div class="col-6">
                                <div class="form-group">
                                <label for="inputStatus">Package</label>
                                <select id="inputStatus" name="package_id" class="form-control custom-select">
                                    <option value="{{$editData->package_id}}">{{$editData->package_name}}</option>
                                    @foreach ($allPackage as $package)
                                        <option value="{{$package->id}}">{{$package->package_name}}</option>
                                    @endforeach
                                </select>
                                </div>
                            </div>
                        </div>
        
                          <div class="row">

                            <div class="col-8">
                              <div class="form-group">
                                <label for="inputowner">Home Owner Name</label>
                                <input type="text" id="inputowner" name="home_owner_name" value="{{$editData->home_owner_name}}" class="form-control">
                              </div>
                            </div>
                            
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="discount_price">Discount Price</label>
                                    <input type="number" name="discount_price" value="{{$editData->discount_price}}" id="discount_price" class="form-control">
                                  </div>
                            </div>
                          </div>
                         
        
                          <div class="form-group">
                            <label for="inputDescription">Address</label>
                            <textarea id="inputDescription" name="address" class="form-control" rows="4">{{$editData->address}}</textarea>
                          </div>
        
                      
        
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="inputmobile">Mobile</label>
                                    <input type="text" name="mobile" value="{{$editData->mobile}}" id="inputmobile" class="form-control">
                                </div>
                            </div>
        
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="inputmobile">Connection Date</label>
                                    <input type="date" name="connection_date" value="{{$editData->connection_date}}" id="inputmobile" class="form-control">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary float-right">Update</button>
                      </div>
                </form>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
@endsection