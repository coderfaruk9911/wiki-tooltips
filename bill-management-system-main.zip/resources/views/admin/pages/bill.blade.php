@extends('admin.layouts.master')


@section('admin-content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="float-right">Bill Collection</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a></li>
              <li class="breadcrumb-item active">Bill Collection</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-6">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-10">

            <div class="card">
                <form action="{{route('bill.store',$customer->user_id)}}" method="post">
                    @csrf
                    <div class="card-body">

                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label for="name">Customer Name</label>
                                    <input type="text" id="name" readonly name="customer_name" value="{{$customer->name}}" class="form-control">
                                  </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label for="name">User ID</label>
                                    <input type="text" readonly id="name" name="customer_id" value="{{$customer->user_id }}" class="form-control">
                                  </div>
                            </div>
                            <div class="col-2">
                              <div class="form-group">
                                  <label for="granted_price">Price</label>
                                  <input type="text" readonly id="granted_price" name="granted_price" value="{{$customer->price - $customer->discount_price}}" class="form-control">
                                </div>
                          </div>
        
                            <div class="col-5">
                                <div class="form-group">
                                <label for="inputStatus">Month</label>
                                <select id="inputStatus" name="month" class="form-control custom-select">
                                    <option selected disabled>Select Month</option>
                                        <option value="January">January</option>
                                        <option value="February">February</option>
                                        <option value="March">March</option>
                                        <option value="April">April</option>
                                        <option value="May">May</option>
                                        <option value="June">June</option>
                                        <option value="July">July</option>
                                        <option value="August">August</option>
                                        <option value="September">September</option>
                                        <option value="October">October</option>
                                        <option value="November">November</option>
                                        <option value="December">December</option>
                                </select>
                                </div>
                            </div>

                        </div>
                         
                        <button type="submit" class="btn btn-primary float-right">Recept</button>
                      </div>
                </form>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
@endsection