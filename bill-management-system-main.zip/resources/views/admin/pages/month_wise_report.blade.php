@extends('admin.layouts.master')


@section('admin-content')
<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-7">
            <h1 class="float-right">Month Wise Report</h1>
          </div>
          <div class="col-sm-5">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a></li>
              <li class="breadcrumb-item active">Month Report</li>
            </ol>
          </div>
        </div>
      </div>
    </section>


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <form action="{{route('monthly_paid.customer')}}" method="post" class="form-inline justify-content-center">
                    @csrf
                    <div class="form-group mx-sm-3 mb-2">
                        <select class="form-control select2" name="year" style="width: 100%;">
                            <option selected="selected">Select Year</option>
                            <option value="2022">2022</option>
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                            <option value="2025">2025</option>
                            <option value="2026">2026</option>
                          </select>
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <select class="form-control select2" name="month" style="width: 100%;">
                            <option selected="selected">Select Month</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                            
                          </select>
                    </div>
                    <button type="submit" class="btn btn-primary mb-2">View Report</button>
                  </form>
            </div>
        </div>
      </div>
    </section>
  </div>
@endsection