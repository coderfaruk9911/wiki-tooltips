@extends('admin.layouts.master')


@section('admin-content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="float-right">Update Package Info</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a></li>
              <li class="breadcrumb-item"><a href="{{route('package.view')}}">All Package</a></li>
              <li class="breadcrumb-item active">edit Package</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Error Massage -->
    <div class="container">
      <div class="row d-flex justify-content-center">
          <div class="col-6">
              @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
              @endif
          </div>
      </div>
  </div>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-8">

            <div class="card">
                <form action="{{route('package.update',$editData->id)}}" method="post">
                    @csrf
                    <div class="card-body">
                        <div class="form-group">
                          <label for="inputPackage">Package Name</label>
                          <input type="text" id="inputPackage" name="package_name" value="{{$editData->package_name}}" class="form-control">
                        </div>
        
                        <div class="form-group">
                          <label for="inputSpeed">Package Speed(Mbps)</label>
                          <input type="text" id="inputSpeed" name="speed" value="{{$editData->speed}}" class="form-control">
                        </div>
                        
                        <div class="form-group">
                          <label for="inputprice">Price</label>
                          <input type="text" name="price" value="{{$editData->price}}" id="inputprice"  class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary float-right">Update</button>
                      </div>
                </form>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
@endsection