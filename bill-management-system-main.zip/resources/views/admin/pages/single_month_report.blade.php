@extends('admin.layouts.master')

@section('admin-content')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Monthly Paid Customers</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{url('/home')}}">Home</a></li>
                <li class="breadcrumb-item active">Monthly Paid Customer</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            


            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fa fa-id-card"></i> BornoSky
                    <small class="float-right">Date: {{$today = date("F j, Y");}}</small>
                  </h4>
                </div>
                <!-- /.col -->
              </div>


              <!-- Table row -->
              <div class="row mt-5">
                <div class="col-12 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr>
                      <th>S.L</th>
                      <th>Name</th>
                      <th>User ID</th>
                      <th>Status</th>
                      <th>Price</th>
                    </tr>
                    </thead>
                    <tbody>

                    <tr>
                    @foreach ($PaidCustomers as $key => $row)
                      <td>{{++$key}}</td>
                      <td>{{$row->customer_name}}</td>
                      <td>{{$row->customer_id}}</td>
                      <td>@if($row->status==1) <span class="badge badge-success w-75">Paid</span> @else <span class="badge badge-Danger">Due</span> @endif</td>
                      <td>{{$row->granted_price}}</td>
                    </tr>
                    @endforeach

                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                  
                </div>
                <!-- /.col -->
                <div class="col-6 mt-5">
                  <p class="lead"></p>

                  <div class="table-responsive">
                    <table class="table">
                      <tr>
                        <th>Total:</th>
                        {{-- <td>{{$total}}  TK.</td> --}}
                      </tr>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
              <div class="row no-print">
                <div class="col-12">
                  <a href="#" class="btn btn-default"><i class="fas fa-print"></i> Print</a>
                  <button type="button" class="btn btn-primary float-right" style="margin-right: 5px;">
                    <i class="fas fa-download"></i> Generate PDF
                  </button>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>


@endsection