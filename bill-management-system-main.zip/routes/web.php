<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\{PackageController,CustomerController,BillController,ReportController};
use Illuminate\Support\Facades\Auth;



Route::get('/', function () {return redirect()->route('login');});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::prefix('admin')->middleware('auth')->group(function () {

    /************************************************************
     ***               Package Route Are Here                 ***
     ************************************************************/
    Route::get('/package/view', [PackageController::class, 'view'])->name('package.view');
    Route::post('/package/store', [PackageController::class, 'store'])->name('package.store');
    Route::get('/package/edit/{id}', [PackageController::class, 'edit'])->name('package.edit');
    Route::post('/package/update/{id}', [PackageController::class, 'update'])->name('package.update');
    Route::get('/package/delete/{id}', [PackageController::class, 'delete'])->name('package.delete');

    /************************************************************
     ***               Customer Route Are Here                ***
     ************************************************************/
    Route::get('/customer/view', [CustomerController::class, 'view'])->name('customer.view');
    Route::post('/customer/store', [CustomerController::class, 'store'])->name('customer.store');
    Route::get('/customer/edit/{id}', [CustomerController::class, 'edit'])->name('customer.edit');
    Route::post('/customer/update/{id}', [CustomerController::class, 'update'])->name('customer.update');
    Route::get('/customer/delete/{id}', [CustomerController::class, 'delete'])->name('customer.delete');
    Route::get('/customer/details/{id}', [CustomerController::class, 'details'])->name('customer.details');

    /************************************************************
     ***         Bill Collection  Route Are Here              ***
     ************************************************************/
    Route::get('/bill/view', [BillController::class, 'view'])->name('bill.view');
    Route::post('/bill/store/{id}', [BillController::class, 'recept'])->name('bill.store');
    Route::get('/bill/receiptId/{id}', [BillController::class, 'receiptId'])->name('bill.receiptId');

    /************************************************************
     ***           Month Wise Report Route Are Here           ***
     ************************************************************/
    Route::get('/month_wise_report/view', [ReportController::class, 'view'])->name('month_wise_report.view');
    Route::post('/month_wise_report/monthly_paid_customer/', [ReportController::class, 'monthly_paid'])->name('monthly_paid.customer');
    Route::post('/month_wise_report/paid_customer/', [ReportController::class, 'paidCustomer'])->name('monthly_paid.customer');
    // Route::post('/month_wise_report/customer_due/', [ReportController::class, 'DueCustomer'])->name('monthly_due.customer');



    });

