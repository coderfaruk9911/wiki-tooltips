<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Package;
use Toastr;

class PackageController extends Controller
{
    public function view(){
        $allPackage = Package::all();
        return view('admin.pages.package',compact('allPackage'));
    }


    public function store(Request $request){
        $validated = $request->validate([
            'package_name' => 'required|unique:packages|max:191',
            'speed' => 'required|unique:packages|max:3|digits_between:0,9',
            'price' => 'required|max:11|digits_between:0,9',
        ]);

        $data = new Package();
        $data->package_name = $request->package_name;
        $data->speed = $request->speed;
        $data->price = $request->price;
        $result = $data->save();
        if ($result) {
            $notification = array(
                'messege' => 'Package Add Successfully',
                'alert-type' => 'success'
            );
        return redirect()->back()->with($notification);
        }
    }

    public function edit($id){
        $editData = Package::findOrFail($id);
        return view('admin.pages.editPackage', compact('editData'));
    }

    public function update(Request $request, $id){
        $validated = $request->validate([
            'package_name' => 'required|max:191',
            'speed' => 'required|max:3|digits_between:0,9',
            'price' => 'required|max:11|digits_between:0,9',
        ]);

        $data = Package::findOrFail($id);
        $package_name_exist = Package::where('package_name', '=', $request->package_name)->first();
        $speed_exist = Package::where('speed', '=', $request->speed)->first();

        if($package_name_exist==null && $speed_exist==null){
            $data->package_name = $request->package_name;
            $data->speed = $request->speed;
            $data->price = $request->price;
            $result = $data->save();

            if ($result) {
                $notification = array(
                    'messege' => 'Package Update Successfully',
                    'alert-type' => 'success'
                );
            return redirect()->route('package.view')->with($notification);
            }
            else{
                $notification = array(
                    'messege' => 'Something Went Wrong',
                    'alert-type' => 'error'
                );
                return redirect()->route('package.view')->with($notification);
            }

        }else{
            $notification = array(
                'messege' => 'Please Change Package Name & Package Speed MBPS!',
                'alert-type' => 'error'
            );
            return redirect()->back()->with($notification);
       
        }

        
    }

    public function delete($id){
        $result=Package::findOrFail($id)->delete();
        if ($result) {
            $notification = array(
                'messege' => 'Package Delete Successfully',
                'alert-type' => 'success'
            );
            return redirect()->route('package.view')->with($notification);
        }else{
            $notification = array(
                'messege' => 'Something Went Wrong ! Please Try Again',
                'alert-type' => 'success'
            );
            return redirect()->route('package.view')->with($notification);
        }
       
    }
}
