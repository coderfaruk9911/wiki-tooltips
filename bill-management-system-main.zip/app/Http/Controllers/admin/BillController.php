<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Bill,Customer};

class BillController extends Controller
{
    public function view(){
        $allCustomer = Customer::join('packages', 'customers.package_id', '=', 'packages.id')
        ->select('customers.*', 'packages.*')
        ->get();
        return view('admin.pages.bill_view',compact('allCustomer'));
    }

    public function receiptId($id){
        $customer = Customer::join('packages', 'customers.package_id', '=', 'packages.id')
        ->select('customers.*', 'packages.*')
        ->where('user_id',$id)->first();
        return view('admin.pages.bill', compact('customer'));
    }

    public function recept(Request $request, $id){
        $validated = $request->validate([
            'month' => 'required',
        ]);



        $data = Customer::where('user_id',$id)->first();

        $data->user_id = $data->user_id;
        $data->name = $data->name;
        $data->package_id = $data->package_id;
        $data->discount_price = $data->discount_price;
        $data->address = $data->address;
        $data->home_owner_name = $data->home_owner_name;
        $data->mobile = $data->mobile;
        $data->connection_date = $data->connection_date;



    
        if($request->month=='January' &&  $data->jan==null){$data->jan = 1;}
        if($request->month=='February' &&  $data->feb==null){$data->feb = 1;}
        if($request->month=='March' &&  $data->mar==null){$data->mar = 1;}
        if($request->month=='April' &&  $data->apr==null){$data->apr = 1;}
        if($request->month=='May' &&  $data->may==null){$data->may = 1;}
        if($request->month=='June' &&  $data->jun==null){$data->jun = 1;}
        if($request->month=='July' &&  $data->jul==null){$data->jul = 1;}
        if($request->month=='August' &&  $data->aug==null){$data->aug = 1;}
        if($request->month=='September' &&  $data->sep==null){$data->sep = 1;}
        if($request->month=='October' &&  $data->oct==null){$data->oct = 1;}
        if($request->month=='November' &&  $data->nov==null){$data->nov = 1;}
        if($request->month=='December' &&  $data->dce==null){$data->dce = 1;}

    
        $result = $data->save();
        if ($result) {
            $notification = array(
                'messege' => 'Receipt Payment Successfully',
                'alert-type' => 'success'
            );
            return redirect()->route('bill.view')->with($notification);
        }else{
            $notification = array(
                'messege' => 'Something Went Wrong ! Please Try Again',
                'alert-type' => 'success'
            );
            return redirect()->route('bill.view')->with($notification);
        }

    }

}
