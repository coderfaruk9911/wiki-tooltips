<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Customer,Package};

class CustomerController extends Controller
{
    public function view(){
        $allCustomer = Customer::join('packages', 'customers.package_id', '=', 'packages.id')
        ->select('customers.*', 'packages.*')
        ->get();
        $allPackage = Package::all();
        return view('admin.pages.customers',compact('allCustomer','allPackage'));
    }


    public function store(Request $request){
        $validated = $request->validate([
            'name' => 'required|max:191',
            'package_id' => 'required',
            'mobile' => 'required|regex:/(0)[0-9]/|not_regex:/[a-z]/|size:11',
            'discount_price' => 'max:111|digits_between:0,9',
            'connection_date' => 'required',
        ]);


        $data = new Customer();
        $lastId = Customer::latest('id')->first();
        $lastId == null ? $data->user_id  = '000001' : $data->user_id  = str_pad(($lastId->user_id + 1),6, "0", STR_PAD_LEFT);
        $data->name = $request->name;
        $data->package_id = $request->package_id;
        $data->discount_price = $request->discount_price;
        $data->address = $request->address;
        $data->home_owner_name = $request->home_owner_name;
        $data->mobile = $request->mobile;
        $data->connection_date = $request->connection_date;
        $result = $data->save();
        return redirect()->back();
    }

    public function edit($id){
        $editData = Customer::join('packages', 'customers.package_id', '=', 'packages.id')
                ->select('customers.*', 'packages.package_name')
                ->where('user_id',$id)->first();  
                
        $allPackage = Package::all();
        return view('admin.pages.editCustomer', compact('editData','allPackage'));
    }

    public function update(Request $request, $id){
        $validated = $request->validate([
            'name' => 'required|max:191',
            'package_id' => 'required',
            'mobile' => 'required|regex:/(0)[0-9]/|not_regex:/[a-z]/|size:11',
            'discount_price' => 'max:111|digits_between:0,9',
            'connection_date' => 'required',
        ]);


        $data = Customer::findOrFail($id);
        $data->user_id = $data->user_id;
        $data->name = $request->name;
        $data->package_id = $request->package_id;
        $data->discount_price = $request->discount_price;
        $data->address = $request->address;
        $data->home_owner_name = $request->home_owner_name;
        $data->mobile = $request->mobile;
        $data->connection_date = $request->connection_date;
        $result = $data->save();
        if ($result) {
            $notification = array(
                'messege' => 'Customer Update Successfully',
                'alert-type' => 'success'
            );
            return redirect()->route('customer.view')->with($notification);
        }else{
            $notification = array(
                'messege' => 'Something Went Wrong ! Please Try Again',
                'alert-type' => 'success'
            );
            return redirect()->route('customer.view')->with($notification);
        }
    }

    public function delete($id){
        $result = Customer::where('user_id',$id)->delete();
                if ($result) {
                    $notification = array(
                        'messege' => 'Customer Delete Successfully',
                        'alert-type' => 'success'
                    );
                    return redirect()->route('customer.view')->with($notification);
                }else{
                    $notification = array(
                        'messege' => 'Something Went Wrong ! Please Try Again',
                        'alert-type' => 'success'
                    );
                    return redirect()->route('customer.view')->with($notification);
        }
    }

    public function details($id){
        $customer = Customer::join('packages', 'customers.package_id', '=', 'packages.id')
        ->select('customers.*', 'packages.*')
        ->where('user_id',$id)->first();
        return view('admin.pages.customer_details', compact('customer'));

    }
}
