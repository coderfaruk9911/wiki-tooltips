<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Bill,Customer};

class ReportController extends Controller
{
    public function view(){
        return view('admin.pages.month_wise_report');
    }
    
    public function paidCustomer(Request $request){
        if($request->month=='January'){
            $PaidCustomers = Customer::where('jan', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='February'){
            $PaidCustomers = Customer::where('feb', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='March'){
            $PaidCustomers = Customer::where('mar', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='April'){
            $PaidCustomers = Customer::where('apr', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='May'){
            $PaidCustomers = Customer::where('may', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='June'){
            $PaidCustomers = Customer::where('jun', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='July'){
            $PaidCustomers = Customer::where('jul', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='August'){
            $PaidCustomers = Customer::where('aug', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='September'){
            $PaidCustomers = Customer::where('sep', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='October'){
            $PaidCustomers = Customer::where('oct', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='November'){
            $PaidCustomers = Customer::where('nov', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        if($request->month=='December'){
            $PaidCustomers = Customer::where('dce', '=', 1)->get();
            return view('admin.pages.single_month_report',compact('PaidCustomers'));
        }
        

        // $total = Bill::where('year', '=', $request->year)
        // ->where('month', '=', $request->month)
        // ->sum('granted_price');


        
    }

    // public function DueCustomer(Request $request){

    //     // $PaidCustomers = Customer::all();

    //     $PaidCustomers = Customer::join('bills', 'customers.id', '=', 'bills.customer_id')
    //     ->select('customers.*', 'bills.*')
    //     // ->where('year', '!=', $request->year)
    //     // ->where('month', '!=', $request->month)
    //     ->where('status', '!=', 1)
    //     ->get();


    //     dd($PaidCustomers);

    //     // $PaidCustomers = Bill::where('year', '=', $request->year)
    //     // ->where('month', '=', $request->month)
    //     // ->get();

    //     $total = Bill::where('year', '=', $request->year)
    //     ->where('month', '=', $request->month)
    //     ->sum('granted_price');


    //     return view('admin.pages.single_month_report',compact('PaidCustomers','total'));

    // }
}
